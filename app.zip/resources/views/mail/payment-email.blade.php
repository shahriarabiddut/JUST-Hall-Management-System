<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hall Room Balance Payment </title>
</head>
<body>
	<h1>{{ $objective }}</h1>
	<p>{{ $body }}</p>
	<p>Thank You.</p>
	<h1> Hall Automation Just</h1>

</body>
</html>
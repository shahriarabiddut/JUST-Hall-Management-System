<h1> Mail from Admin</h1>
<p><?php echo e($body); ?> </p>
<?php if($objective == 'payment'): ?>
    <h3 class="text-info"> Payment Issue !</h3>
<?php endif; ?>
<h1> Recieved</h1><?php /**PATH C:\xampp\htdocs\smtp\resources\views/admin/email/email-template.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Support Ticket Details'); ?>
<?php $__env->startSection('content'); ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Support Ticket Details of <?php echo e($data->student->name); ?> - <?php echo e($data->student->rollno); ?> 
            <a href="<?php echo e(url('admin/support')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h3>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <tr>
                        <th>Ticket No</th>
                        <td><?php echo e($data->id); ?></td>
                    </tr>
                    <tr>
                        <th>Ticket By</th>
                        <td><?php echo e($data->student->name); ?> - <?php echo e($data->student->rollno); ?> </td>
                    </tr>
                    <tr>
                        <th>Subject</th>
                        <td><?php echo e($data->subject); ?></td>
                    </tr><tr>
                        <th>Details</th>
                        <td><?php echo e($data->message); ?></td>
                    </tr>
                    <tr>
                        <th>Reply</th>
                        <td>
                            <?php if($data->reply): ?>
                            <?php echo e($data->reply); ?>

                            <?php else: ?>
                            No Reply Yet!
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Replied By</th>
                        <td>
                            <?php if($data->reply): ?>
                            <?php echo e($data->staff->name); ?>

                            <?php else: ?>
                            No Reply Yet!
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Ticket Creation Date</th>
                        <td><?php echo e($data->created_at); ?></td>
                    </tr>
                    <tr>
                        <th>Ticket Replied Date</th>
                        <td><?php echo e($data->updated_at); ?></td>
                    </tr>
                   
                    
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/admin/support/show.blade.php ENDPATH**/ ?>
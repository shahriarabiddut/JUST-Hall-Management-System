<?php $__env->startSection('title', 'Staff Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Row -->
<div class="row">

    <!-- Bookings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Orders <?php echo e($nextDate); ?></div> 
                            
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(App\Models\Order::all()->where('date','=',$nextDate)->count()); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Customers (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Students</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(App\Models\Student::count()); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Rooms (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Rooms
                        </div>
                        <div class="row no-gutters align-items-center">
                            <div class="col-auto">
                                <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e(App\Models\Room::count()); ?></div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pending Requests Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Staff</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(App\Models\Staff::count()); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content Row For Order Data of Next Day -->
<div class="row">

    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="col-sm-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 
                <?php switch($resulttitle[$key]->title):
                    case ('Launch'): ?>
                        bg-warning
                        <?php break; ?>
                    <?php case ('Dinner'): ?>
                        bg-info
                        <?php break; ?>
                    <?php case ('Suhr'): ?>
                        bg-dark
                        <?php break; ?>
                    <?php case ('Special'): ?>
                        bg-danger
                        <?php break; ?>
                    <?php default: ?>
                        bg-secondary
                <?php endswitch; ?>
                ">
                    <h6 class="m-0 font-weight-bold text-white ">
                        <?php echo e($resulttitle[$key]->title); ?> Orders <i class="fas 
                        <?php switch($resulttitle[$key]->title):
                    case ('Launch'): ?>
                        fa-sun
                        <?php break; ?>
                    <?php case ('Dinner'): ?>
                        fa-star
                        <?php break; ?>
                    <?php case ('Suhr'): ?>
                        fa-moon
                        <?php break; ?>
                    <?php case ('Special'): ?>
                        fa-star
                        <?php break; ?>
                    <?php default: ?>
                        bg-secondary
                <?php endswitch; ?>
                        "></i>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($key):
                                    case (1): ?>
                                        <table class="p-4 table-bordered float-left" width="50%">
                                            <tbody>
                                        <?php $__currentLoopData = $ld; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr><th class="p-4 text-center"><?php echo e($foods->food_name); ?> </th> </tr>
                                        
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                        <?php break; ?>
                                    <?php case (0): ?>
                                        <table class="table-bordered float-right" width="50%">
                                            <tbody>
                                            <?php $__currentLoopData = $ld; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foodscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr><th class="p-4 text-center"><?php echo e($foodscount); ?></th> </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php break; ?>
                                    <?php default: ?>
                                    <table class="table-bordered float-right" width="50%">
                                        <tbody>
                                        <tr><th class="p-4 text-center">No Data Available</th> </tr>
                                        </tbody>
                                    </table>
                                <?php endswitch; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Larahall\resources\views/staff/dashboard.blade.php ENDPATH**/ ?>
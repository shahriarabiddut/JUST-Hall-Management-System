
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha384-vk5WoKIaW/vJyUAd9n/wmopsmNhiy+L2Z+SBxGYnUkunIxVxAv/UtMOhba/xskxh" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/jquery-searchbox.js')); ?>"></script>
<?php $__env->startSection('title', 'Edit Room Allocation'); ?>
<?php $__env->startSection('content'); ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Editing Room Allocation: <?php echo e($data->name); ?>

            <a href="<?php echo e(url('staff/roomallocation/'.$data->id)); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h3>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
            <form method="POST" action="<?php echo e(route('staff.roomallocation.update',$data->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tbody>
                        <tr>
                            <th width="30%" >Student</th>
                            <td>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($data->user_id==$st->id): ?>
                                   <?php echo e($st->name); ?> - <?php echo e($st->rollno); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                    <tr>
                        <th>Select RoomNo</th>
                            <td>
                                <select required name="room_id" class="form-control room_id" id="select_room" onchange="fetchAndPopulateData()">
                                    <option value="0">--- Select RoomNo ---</option>
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php if($data->room_id==$rm->id): ?>
                                        <?php if(true): echo 'selected'; endif; ?>
                                    <?php endif; ?>
                                     value="<?php echo e($rm->id); ?>"><?php echo e($rm->title); ?>  <?php if($data->room_id==$rm->id): ?> (selected) <?php endif; ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                    </tr>
                    <tr>
                    <th>Position <span class="text-danger">*</span></th>
                        <td><select name="position" class="form-control" id="positions">
                        </select></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="hidden" name="old_position" value="<?php echo e($data->position); ?>">
                            <input type="hidden" name="old_room_id" value="<?php echo e($data->room_id); ?>">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>

    <!-- Add Search in select Options custom scripts -->

    <script>
        $(function(){
         $("#select_student").select2();
        }); 
        $(function(){
         $("#select_room").select2();
        }); 
        $('.js-searchBox').searchBox({ elementWidth: '100%'});
        $('.user_id').searchBox({ elementWidth: '100%'});
        $('.room_id').searchBox({ elementWidth: '100%'});
       </script>
<script>
    function fetchAndPopulateData() {
        let selectedValue = document.getElementById("select_room").value;

        // Make Ajax request to fetch data
        fetch('<?php echo e(url("staff/room")); ?>/postion/' + selectedValue)
            .then(response => response.json())
            .then(data => {
                // Update the options of the second select field
                let secondSelectField = document.getElementById("positions");
                secondSelectField.innerHTML = ""; // Clear existing options
                let arrayString = data;

                // Parse the string into a JavaScript array
                let dataArray = JSON.parse(arrayString);

                // Get the select field element
                let selectField = document.getElementById("positions");

                // Populate the select field with options based on the array
                if(<?php echo e($data->room_id); ?> == selectedValue){
                let option = document.createElement("option");
                    option.value = <?php echo e($data->position); ?>;
                    option.text = <?php echo e($data->position); ?> + '(Old Position)';
                    selectField.add(option);
                }
                dataArray.forEach(function(value) {
                    let option = document.createElement("option");
                    option.value = value;
                    option.text = value;
                    selectField.add(option);
                });
                
            })
            .catch(error => console.error('Error:', error));
    }
</script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/staff/roomallocation/edit.blade.php ENDPATH**/ ?>
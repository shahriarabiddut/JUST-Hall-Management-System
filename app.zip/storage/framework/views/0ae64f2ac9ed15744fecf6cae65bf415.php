
<?php $__env->startSection('title', 'Edit Request Room Allocation'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Edit Request Room Allocation</h1>
<?php if($sorryAllocatedSeat==1): ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary ">You have allready Requested
    </div>
</div>
<?php elseif($sorryAllocatedSeat==2): ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary ">Room Allocation Accepted
    </div>
</div>
<?php else: ?>
 <!-- DataTales Example -->
 <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Room Allocation request
    </div>
    <div class="card-body">
        
        <div class="table-responsive">
            <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <p class="text-danger"> <?php echo e($error); ?> </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <form method="POST" action="<?php echo e(route('student.roomrequest.update')); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <tbody>
                <tr>
                    <th>Select RoomNo</th>
                        <td>
                            <select required name="room_id" class="form-control room_id">
                                <option value="0">--- Select Room No ---</option>
                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rm->id); ?>" <?php if($data->room_id ==$rm->id): ?>
                                    <?php if(true): echo 'selected'; endif; ?>
                                <?php endif; ?>
                                ><?php echo e($rm->title); ?> - (Vacancy <?php echo e($rm->vacancy); ?> )</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                </tr>
                <tr>
                <th>Your Application <span class="text-danger">*</span></th>
                    <td>
                        <textarea name="message" id="" cols="10" rows="20" class="form-control"><?php echo e($data->message); ?></textarea>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                        <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                        <button type="submit" class="btn btn-primary">Update</button>
                    </td>
                </tr>
                </tbody>
            </table>
        </form>
        </div>
    </div>
</div>
<?php endif; ?>
   

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/profile/room/roomrequestedit.blade.php ENDPATH**/ ?>
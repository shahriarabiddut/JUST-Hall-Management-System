
<?php $__env->startSection('title', 'Edit Room'); ?>
<?php $__env->startSection('content'); ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Editing Room : <?php echo e($data->title); ?>

            <a href="<?php echo e(url('admin/rooms/'.$data->id)); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h3>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
            <form method="POST" action="<?php echo e(route('admin.rooms.update',$data->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tbody>
                    <tr>
                        <th>Title</th>
                        <td><input name="title" value="<?php echo e($data->title); ?>" type="text" class="form-control"></td>
                    </tr>
                    <tr>
                        <th>Select Room Type</th>
                        <td>
                            <select name="rt_id" class="form-control">
                                <?php $__currentLoopData = $roomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($data->room_type_id==$rt->id): ?>
                                    <?php if(true): echo 'selected'; endif; ?>
                                <?php endif; ?>
                                 value="<?php echo e($rt->id); ?>"><?php echo e($rt->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Total Seats</th>
                        <td><input required name="totalseats" type="number" class="form-control" value="<?php echo e($data->totalseats); ?>"></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/admin/room/edit.blade.php ENDPATH**/ ?>
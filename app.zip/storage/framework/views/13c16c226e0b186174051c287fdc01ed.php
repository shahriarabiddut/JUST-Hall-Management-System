
<?php $__env->startSection('title', 'Student'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Students</h1>
    <p class="mb-4">Student Data</p>
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Student Data
            <a href="<?php echo e(route('admin.student.create')); ?>" class="float-right btn btn-success btn-sm" target="_blank">Add New </a> </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Photo</th>
                            <th>RollNo</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Photo</th>
                            <th>RollNo</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><img width="100"
                                class=""
                                src="<?php echo e($d->photo ? asset('storage/'.$d->photo) : url('storage/images/user.png')); ?>"
                                alt=""
                            /></td>
                            <td><?php echo e($d->rollno); ?></td>
                            <td><?php echo e($d->name); ?></td>
                            <td><?php echo e($d->email); ?></td>
                            <td><?php echo e($d->mobile); ?></td>
                            
                            
                            <td class="text-center">
                                <a href="<?php echo e(url('admin/student/'.$d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                <a href="<?php echo e(url('admin/student/'.$d->id.'/edit')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i></a>
                                <a onclick="return confirm('Are You Sure?')" href="<?php echo e(url('admin/student/'.$d->id.'/delete')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MultiAuth\resources\views/admin/student/index.blade.php ENDPATH**/ ?>
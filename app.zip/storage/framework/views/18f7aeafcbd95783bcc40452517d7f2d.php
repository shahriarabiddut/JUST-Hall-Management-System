
<?php $__env->startSection('title', 'Create Order For Meal'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Create Order Meal </h1>
        <!-- Session Messages Starts -->

        <?php if(Session::has('danger')): ?>
        <div class="p-3 mb-2 bg-danger text-white">
            <p><?php echo e(session('danger')); ?> </p>
        </div>
        <?php endif; ?>
        <!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Add Order 
            <a href="<?php echo e(url('student/order')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h6>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
            <form method="POST" action="<?php echo e(route('student.order.storeAdvance')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tbody>
                    <tr>
                    <th>Order Type<span class="text-danger">*</span></th>
                        <td>
                        <input readonly value="<?php echo e($food_time->title); ?>" name="order_type" type="text" class="form-control">
                        </td>
                    </tr>
                    <tr>
                        <th>Advance Order Date<span class="text-danger">*</span></th>
                            <td>
                            <input id='date' name="date" type="date" class="form-control">
                            </td>
                        </tr>
                    <tr>
                        <th>Select Food<span class="text-danger">*</span></th>
                            <td>
                                <select required name="food_item_id" class="form-control">
                                    <option value="0">--- Select Food ---</option>
                                    <?php $__currentLoopData = $food; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ft->id); ?>"><?php echo e($ft->food_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                    
                    <tr>
                        <th> Quantity <span class="text-danger">*</span></th>
                            <td><select required name="quantity" class="form-control room-list">
                                <?php if(isset($dataquantity)): ?>
                                <option value="0">--- Select ---</option>
                                <option value="1">1</option>
                                <?php else: ?>
                                <option value="0">--- Select ---</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <?php endif; ?>
                                
                            </select></td>
                        </tr> 
                    <tr>
                        <td colspan="2">
                            <input value="<?php echo e(Auth::user()->id); ?>" name="student_id" type="hidden" class="form-control">
                            <input value="<?php echo e($food_time->id); ?>" name="food_time_id" type="hidden" class="form-control">
                            <button type="submit" class="btn btn-primary btn-block">Place Order</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>" defer> </script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>" defer></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script type="text/javascript">
        // Hiding Old Dates
        const dateField1 = document.getElementById('date');
        const currentDate = new Date();
        // Add one day
        currentDate.setDate(currentDate.getDate() + 2);
        // Format the date as ISO string
        const tomorrow = currentDate.toISOString().split('T')[0];
        dateField1.setAttribute('min', tomorrow);
        // dateField1.setAttribute('max', tomorrow);

        //Auto Input Date For tommorow
        let currentDatex = new Date();
        let month = currentDatex.getMonth() + 1;
        if(month<=9){
            month='0'+month;
        }
        let day = currentDatex.getDate()+1;
        if(day<=9){
            day='0'+day;
        }
        let year = currentDatex.getFullYear()
        dateField1.value = year + "-"+month+"-"+day;
        
        // Hiding Old Dates
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Registrar 2\resources\views/profile/order/createAdvance.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Mealtoken Details'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"> Mealtoken Details </h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Mealtoken Details 
            <a href="<?php echo e(url('student/mealtoken')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h6>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <tr>
                        <th width="60%">Meal Type</th>
                        <td width="40%"><?php echo e($data->meal_type); ?></td>
                    </tr>
                    <tr>
                        <th>Meal</th>
                        <td><?php echo e($data->food_name); ?></td>
                    </tr>
                    <tr>
                        <th>Quantity</th>
                        <td><?php echo e($data->quantity); ?></td>
                    </tr>
                    <tr>
                        <th>Printed Date</th>
                        <td>
                            <?php if($data->created_at==$data->updated_at): ?>
                                Not Printed Yet
                            <?php else: ?>
                                <?php echo e($data->updated_at); ?>

                            <?php endif; ?>
                            </td>
                        
                        
                    </tr>
                    <tr>
                        <th>Status</th>
                        <?php switch($data->status):
                            case (0): ?>
                               <td class="bg-success text-white"> Not Used </td>
                                   <?php break; ?>
                            <?php case (1): ?>
                            <td class="bg-danger text-white"> Used </td>
                                <?php break; ?>
                            <?php case (2): ?>
                            <td class="bg-warning text-white"> Error</td>
                                <?php break; ?>
                            <?php default: ?>
                            <td class="bg-success text-white"> Not Used </td>
                        <?php endswitch; ?>
                    </tr>
                    
                    
                    <tr>
                        <th>Order No</th>
                        <td><?php echo e($data->order_id); ?></td>
                    </tr>
                    <tr>
                        <th>QR Code</th>
                        <td><?php echo e($qrcode); ?></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2">
                            
                            <a  href="<?php echo e(url('student/mealtoken/print/'.$data->id)); ?>" class="float-right btn btn-success btn-sm "><i class="fas fa-ticket-alt"> Print Meal Token </i></a>
                            
                            
                            
                        </td>
                        
                    </tr>
                    
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <style>
        svg {
        height: 150px!important;
        }
    </style>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\2.7 Hall Manage - Meal token Generates with Order\resources\views/profile/mealtoken/show.blade.php ENDPATH**/ ?>
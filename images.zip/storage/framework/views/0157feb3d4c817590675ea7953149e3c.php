
<?php $__env->startSection('title', 'Room Type Details'); ?>
<?php $__env->startSection('content'); ?>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Room Type Details of <?php echo e($data->title); ?> room
            <a href="<?php echo e(url('admin/roomtype')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> 
                
        </h3>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    
                    <tr>
                        <th>Title</th>
                        <td><?php echo e($data->title); ?></td>
                    </tr><tr>
                        <th>Price</th>
                        <td><?php echo e($data->price); ?></td>
                    </tr><tr>
                        <th>Details</th>
                        <td><?php echo e($data->details); ?></td>
                    </tr><tr>
                        <th>Gallery Images</th>
                        <td>
                        <table class="table table-bordered">
                            <tr>
                                <?php $__currentLoopData = $data->roomtypeimages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="imgcol<?php echo e($img->id); ?>">
                                    <img width="200px" src="<?php echo e($img->img_src ? asset('storage/'.$img->img_src) : ''); ?>" alt="<?php echo e($img->img_alt ? asset('storage/'.$img->img_alt) : ''); ?>">
                                </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tr>
                        </table>
                        </td>
                    </tr><tr>
                        <td colspan="2">
                            <a href="<?php echo e(url('admin/roomtype/'.$data->id.'/edit')); ?>" class="float-right btn btn-info btn-sm"><i class="fa fa-edit"> Edit <?php echo e($data->title); ?>  </i></a>
                        </td>
                        
                    </tr>
                    
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/admin/roomType/show.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Orders Search by date '); ?>

<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Orders Search by date</h1>
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
            
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Order History
                <div class="float-right">
                    <form method="POST" action="<?php echo e(route('staff.orders.searchByDate')); ?>">
                        <?php echo csrf_field(); ?>
                        <label for="search-date">Search History by Date:</label>
                        <input type="date" id="search-date" name="date" value="<?php echo e($date); ?>">
                        <button type="submit">Search</button>
                      </form>
                </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>FoodTime</th>
                            <th>FoodName</th>
                            <th>Order Time</th>
                            <th>Quantity</th>
                            <th>OrderNo</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>FoodTime</th>
                            <th>FoodName</th>
                            <th>Order Time</th>
                            <th>Quantity</th>
                            <th>OrderNo</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($d->student->name); ?> - <?php echo e($d->student->rollno); ?></td>
                            <td><?php echo e($d->order_type); ?></td>
                            <td><?php echo e($d->food->food_name); ?></td>
                            <td><?php echo e($d->date); ?></td>
                            <td><?php echo e($d->quantity); ?></td>
                            <td><?php echo e($d->id); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php $__env->startSection('scripts'); ?>
    
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/staff/orders/search.blade.php ENDPATH**/ ?>
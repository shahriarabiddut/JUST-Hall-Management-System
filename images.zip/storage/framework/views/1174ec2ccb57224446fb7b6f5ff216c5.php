<?php $__env->startSection('title', ' My Profile | Student Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Heading -->

    <div class="container py-5">
    <!-- Session Messages Starts -->
    <?php if(Session::has('success')): ?>
    <div class="p-3 mb-2 bg-success text-white">
        <p><?php echo e(session('success')); ?> </p>
    </div>
    <?php endif; ?>
    <?php if(Session::has('danger')): ?>
    <div class="p-3 mb-2 bg-danger text-white">
        <p><?php echo e(session('danger')); ?> </p>
    </div>
    <?php endif; ?>
    <!-- Session Messages Ends -->
      <h1 class="border border-secondary rounded h3 mb-2 text-gray-800 p-2 bg-white"> My Profile </h1>
      

      <div class="row">
        <div class="col-lg-4">
          <div class="card mb-4">
            <div class="card-body text-center">
                <img src="<?php echo e($user->photo ? asset('storage/'.$user->photo) : url('images/user.png')); ?>" alt="User Photo" class="rounded-circle img-fluid" style="width: 150px;">
              <h5 class="my-3"><?php echo e($user->name); ?></h5>
              <p class="text-muted mb-1"><?php echo e($user->email); ?></p>
              <p class="text-muted mb-4"><?php echo e($user->address); ?></p>
              
            </div>
          </div>
          
        </div>
        <div class="col-lg-8">
          <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-3">
                      <p class="mb-0">Roll No</p>
                    </div>
                    <div class="col-sm-9">
                      <p class="text-muted mb-0"><?php echo e($user->rollno); ?></p>
                    </div>
                  </div>
                  <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Full Name</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0"><?php echo e($user->name); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Email</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0"><?php echo e($user->email); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Phone</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0">+88 - <?php echo e($user->mobile); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3">
                  <p class="mb-0">Address</p>
                </div>
                <div class="col-sm-9">
                  <p class="text-muted mb-0"><?php echo e($user->address); ?></p>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-3 float-left">
                  <a href="<?php echo e(route('student.profile.edit')); ?>"><button type="button" class="btn btn-primary">Edit Profile</button></a>
                </div>
                
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </div>



<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Larahall\resources\views/profile/partials/view.blade.php ENDPATH**/ ?>
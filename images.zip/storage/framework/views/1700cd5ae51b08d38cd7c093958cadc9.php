
<?php $__env->startSection('title', 'Send New Email'); ?>
<?php $__env->startSection('content'); ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Send New Email
            <a href="<?php echo e(url('admin/email')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h3>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
                <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <p class="text-danger"> <?php echo e($error); ?> </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(Session::has('error')): ?>
                    <div class="p-3 mb-2 bg-danger text-white">
                        <p><?php echo e(session('danger')); ?> </p>
                    </div>
                <?php endif; ?>
            <form method="POST" action="<?php echo e(route('admin.email.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tbody>
                    <tr>
                   <th>Name <span class="text-danger">*</span></th>
                        <td><input class="form-control" type="text" name="name" placeholder="Name" required <?php echo e(old('name')); ?> ></td>
                    </tr><tr>
                        <th>Email <span class="text-danger">*</span></th>
                        <td><input class="form-control" type="text" name="email" placeholder="Email" required value="<?php echo e(old('email')); ?>"></td></tr>
                    <tr><th>Subject<span class="text-danger">*</span></th>
                        <td><input class="form-control" type="text" name="subject" placeholder="Subject" required value="<?php echo e(old('subject')); ?>"></td>
                    </tr><tr>
                        <th>Message <span class="text-danger">*</span></th>
                        <td><textarea class="form-control" name="message" placeholder="Message"> <?php echo e(old('message')); ?></textarea></td>
                    </tr><tr>
                        <th>Objective<span class="text-danger">*</span></th>
                        <td>
                            <select class="form-control" aria-label="Default select example" name="objective">
                                <option selected value="none" > Select objective </option>
                                <option value="payment">Payment Issue</option>
                                <option value="subscription">Subscription Message</option>
                              </select>
                            </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <input type="hidden" name="staff_id" value="0">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/comillait/public_html/resources/views/admin/email/create.blade.php ENDPATH**/ ?>
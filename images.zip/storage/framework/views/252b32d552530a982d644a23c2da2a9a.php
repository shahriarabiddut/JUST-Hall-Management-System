
<?php $__env->startSection('title', 'Edit Student'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Editing Student: <?php echo e($data->full_name); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Student
            <a href="<?php echo e(url('admin/student/'.$data->id)); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h6>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
            <form method="POST" action="<?php echo e(route('admin.student.update',$data->id)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <tbody>
                    <tr>
                        <th>Roll No <span class="text-danger">*</span></th>
                        <td><input required name="rollno" type="text" class="form-control" value="<?php echo e($data->rollno); ?>"></td>
                    </tr>
                    <tr>
                        <th>Full Name <span class="text-danger">*</span></th>
                        <td><input required name="name" type="text" class="form-control" value="<?php echo e($data->name); ?>"></td>
                    </tr><tr>
                        <th>Email <span class="text-danger">*</span></th>
                        <td><input required name="email" type="email" class="form-control" value="<?php echo e($data->email); ?>"></td>
                    </tr><tr>
                        <th>Mobile No <span class="text-danger">*</span></th>
                        <td><input required name="mobile" type="text" class="form-control" value="<?php echo e($data->mobile); ?>" maxlength="11"></td>
                    </tr><tr>
                        <th>Photo</th>
                        <td><input name="photo" type="file">
                            <td><input name="prev_photo" type="hidden" value="<?php echo e($data->photo); ?>">
                            <img width="100" src="<?php echo e($data->photo ? asset('storage/'.$data->photo) : ''); ?>" >
                        </td>
                    </tr><tr>
                        <th>Address</th>
                        <td><textarea name="address" class="form-control"><?php echo e($data->address); ?></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </form>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Registrar 2\resources\views/admin/student/edit.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Staff Details'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"> Staff Details </h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Staff Details of <?php echo e($data->title); ?> 
            <a href="<?php echo e(url('admin/staff')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h6>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                        <tr>
                            <th>Photo</th>
                            <td><img width="100" src="<?php echo e($data->photo ? asset('storage/'.$data->photo) : url('storage/images/user.png')); ?>" alt="User Photo"></td>
                        </tr><tr>
                            <th>Email </th>
                                 <td><?php echo e($data->email); ?></td>
                             </tr>
                        <tr>
                       <th>Full Name </th>
                            <td><?php echo e($data->name); ?></td>
                        </tr><tr>
                            <th>Department</th>
                            <td><?php echo e($data->department->title); ?></td>
                        </tr><tr>
                            <th>Bio </th>
                            <td><?php echo e($data->bio); ?></td>
                        </tr><tr>
                            <th>Salary Type </th>
                            <td><?php echo e($data->salary_type); ?></td>
                        </tr><tr>
                            <th>Salary Amount</th>
                            <td><?php echo e($data->salary_amount); ?></td>
                        </tr><tr>
                            <td colspan="2">
                                <a href="<?php echo e(url('admin/staff/'.$data->id.'/edit')); ?>" class="float-right btn btn-info btn-sm"><i class="fa fa-edit"> Edit <?php echo e($data->title); ?> </i></a> <a href="<?php echo e(url('admin/staff/'.$data->id.'/change')); ?>" class="float-right btn btn-info btn-sm mr-2"><i class="fa fa-edit"> Change Email & Password <?php echo e($data->title); ?> </i></a>
                            </td>
                            
                        </tr>
                        
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MultiAuth\resources\views/admin/staff/show.blade.php ENDPATH**/ ?>
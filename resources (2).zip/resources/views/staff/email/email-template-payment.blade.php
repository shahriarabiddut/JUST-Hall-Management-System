<h1> Payment Message</h1>
<p>{{ $body }} </p>
<h1> Hall Automation Just</h1>
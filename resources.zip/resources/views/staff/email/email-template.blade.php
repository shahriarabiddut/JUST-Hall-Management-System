<h1> Mail from Inside</h1>
<p>{{ $body }} </p>
@if ($objective == 'payment')
    <h3 class="text-info"> Payment Issue !</h3>
@endif
<h1> Recieved</h1>
<h1>Notification</h1>
{{ $body }}
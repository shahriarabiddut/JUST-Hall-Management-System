
<?php $__env->startSection('title', 'Payments'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Payments</h1>
    <p class="mb-4">Payments</p>
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Payments Data
            <a href="<?php echo e(route('staff.payment.create')); ?>" class="float-right btn btn-success btn-sm" target="_blank">Add New</a> </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Student</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($d->students->name); ?> - <?php echo e($d->students->rollno); ?></td>
                            <td><?php echo e($d->payment_method); ?></td>
                            <td><?php echo e($d->amount); ?></td>
                            <td><?php echo e($d->created_at); ?></td>
                            
                            <?php switch($d->status):
                                case (0): ?>
                                   <td class="bg-warning text-white"> Checking</td>
                                       <?php break; ?>
                                <?php case (1): ?>
                                <td class="bg-success text-white"> Accepted by <?php echo e($d->staff->name); ?></td>
                                    <?php break; ?>
                                <?php case (2): ?>
                                <td class="bg-danger text-white"> Rejected by <?php echo e($d->staff->name); ?></td>
                                    <?php break; ?>
                                <?php default: ?>
                                   <td>   No Action Taken </td>
                            <?php endswitch; ?>
                            
                            <td class="text-center">
                                <a href="<?php echo e(url('staff/payment/'.$d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                <?php if($d->status ==1 || $d->status ==2): ?>
                                <?php else: ?>
                                <a href="<?php echo e(url('staff/payment/'.$d->id.'/accept')); ?>" class="btn btn-success btn-sm"><i class="fa fa-check"></i></a>
                                <a onclick="return confirm('Are You Sure?')" href="<?php echo e(url('staff/payment/'.$d->id.'/reject')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-ban"></i></a>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Larahall\resources\views/staff/payment/index.blade.php ENDPATH**/ ?>
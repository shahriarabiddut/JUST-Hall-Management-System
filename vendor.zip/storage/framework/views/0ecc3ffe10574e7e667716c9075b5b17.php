
<?php $__env->startSection('title', 'Mealtoken Details'); ?>
<?php $__env->startSection('content'); ?>


<!-- Session Messages Starts -->
<?php if(Session::has('success')): ?>
<div class="p-3 mb-2 bg-success text-white">
    <p><?php echo e(session('success')); ?> </p>
</div>
<?php endif; ?>
<?php if(Session::has('danger')): ?>
<div class="p-3 mb-2 bg-danger text-white">
    <p><?php echo e(session('danger')); ?> </p>
</div>
<?php endif; ?>
<!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Mealtoken Details 
            <a href="<?php echo e(url('staff/orders')); ?>" class="float-right btn btn-success btn-sm"> <i class="fa fa-arrow-left"></i> View All </a> </h3>
        </div>
        <div class="card-body <?php echo e($bg); ?> text-white p-2">
            <h1 class="text-center font-weight-bold"> <?php echo e($messageExtra); ?></h1>
        </div>
        <div class="card-body">
            
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <tr>
                        <th width="60%">Meal Type</th>
                        <td width="40%"><?php echo e($data->meal_type); ?></td>
                    </tr>
                    <tr>
                        <th>Meal</th>
                        <td><?php echo e($data->food_name); ?></td>
                    </tr>
                    <tr>
                        <th>Quantity</th>
                        <td><?php echo e($data->quantity); ?></td>
                    </tr>
                    <tr>
                        <th>Printed Date</th>
                        <td>
                            <?php if($data->created_at==$data->updated_at): ?>
                                Not Printed Yet
                            <?php else: ?>
                                <?php echo e($data->updated_at); ?>

                            <?php endif; ?>
                            </td>
                        
                        
                    </tr>
                    <tr>
                        <th>Status</th>
                        <?php switch($data->status):
                            case (3): ?>
                               <td class="bg-info text-white"> Token On Print Queue </td>
                                   <?php break; ?>
                            <?php case (1): ?>
                            <td class="bg-danger text-white"> Used</td>
                                <?php break; ?>
                            <?php case (2): ?>
                            <td class="bg-warning text-white"> Error</td>
                                <?php break; ?>
                            <?php default: ?>
                            <td class="bg-success text-white"> Not Used </td>
                        <?php endswitch; ?>
                    </tr>
                    
                    
                    <tr>
                        <th>Order No</th>
                        <td><?php echo e($data->order_id); ?></td>
                    </tr>
                    <tr>
                        <th>Token No</th>
                        <td><?php echo e($data->id); ?></td>
                    </tr>
                    <tr>
                        <th>Token QR</th>
                        <td><?php echo QrCode::size(300)->generate($data->id); ?></td>
                    </tr>
                    
                    <tr>
                        <td colspan="2" class="m-1">
                            <a href="<?php echo e(route('staff.orders.printToken',$data->order_id)); ?>" class="float-right btn btn-success btn-sm btn-block p-2"><i class="fas fa-ticket-alt"> Print </i></a>           
                            <?php if($data->status!=1): ?>
                            <a href="<?php echo e(route('staff.orders.valid',$data->id)); ?>" class="float-right btn btn-info btn-sm btn-block p-2"><i class="fas fa-ticket-alt"> Mark as Used </i></a> 
                            <?php endif; ?>
                        </td>                            
                    </tr>
                    
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cam\resources\views/staff/orders/show.blade.php ENDPATH**/ ?>
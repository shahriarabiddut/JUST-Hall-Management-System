<?php $__env->startSection('title', 'Student Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<!-- Content Row For Order Spent of Current Month -->
<div class="card-header py-3 my-2 bg-primary">
    <h6 class="m-0 p-3 font-weight-bold text-white bg-info">
        You have Spent this Month : <?php echo e($sumofthatmonth); ?> Taka
</div>

<!-- Content Row For Order Data of Next Day -->
                <div class="card-header py-3 bg-secondary">
                    <h6 class="m-0 font-weight-bold text-white ">
                        My Orders For Next Day  
                </div>

<div class="row m-1 text-center bg-dark">
    <div class="p-1 text-white">
        <i class="fa fa-clock"></i>
        <h6 id="hours" class="d-inline"></h6>
        <h6 id="mins" class="d-inline"></h6>
        <h6 id="secs" class="d-inline"></h6>
        <h6 class="d-inline"> remaining to order today!</h6>
        <h2 id="end" class="d-inline"></h2>
    </div>
</div>

<div class="row">

    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if(isset($result)): ?>
        <div class="col-sm-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 
                <?php switch($resulttitle[$key]->title):
                    case ('Launch'): ?>
                        bg-warning
                        <?php break; ?>
                    <?php case ('Dinner'): ?>
                        bg-info
                        <?php break; ?>
                    <?php case ('Suhr'): ?>
                        bg-dark
                        <?php break; ?>
                    <?php case ('Special'): ?>
                        bg-danger
                        <?php break; ?>
                    <?php default: ?>
                        bg-secondary
                <?php endswitch; ?>
                ">
                    <h6 class="m-0 font-weight-bold text-white ">
                        <?php echo e($resulttitle[$key]->title); ?> Orders <i class="fas 
                        <?php switch($resulttitle[$key]->title):
                    case ('Launch'): ?>
                        fa-sun
                        <?php break; ?>
                    <?php case ('Dinner'): ?>
                        fa-star
                        <?php break; ?>
                    <?php case ('Suhr'): ?>
                        fa-moon
                        <?php break; ?>
                    <?php case ('Special'): ?>
                        fa-star
                        <?php break; ?>
                    <?php default: ?>
                        bg-secondary
                <?php endswitch; ?>
                        "></i>
                </div>
                <div class="card-body"> 
            <?php if($result!=0): ?>
                                <div class="table-responsive">
                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php switch($key):
                                                case (1): ?>
                                                    <table class="p-4 table-bordered float-left" width="50%">
                                                        <tbody>
                                                    <?php $__currentLoopData = $ld; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr><th class="p-4 text-center"><?php echo e($foods->food_name); ?> </th> </tr>
                                                    
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                                    <?php break; ?>
                                                <?php case (0): ?>

                                                    <table class="table-bordered float-right" width="50%">
                                                        <tbody>
                                                        
                                                        <?php $__currentLoopData = $ld; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foodscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr><th class="p-4 text-center"><?php echo e($foodscount); ?></th> </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                    <?php break; ?>
                                                <?php default: ?>
                                                <table class="table-bordered float-right" width="50%">
                                                    <tbody>
                                                    <tr><th class="p-4 text-center">No Data Available</th> </tr>
                                                    </tbody>
                                                </table>
                                            <?php endswitch; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                </div>
                            

                <?php else: ?>
                    <?php if(isset($remainingTime)): ?>
                        <?php if($remainingTime): ?>
                        <p class="text-white bg-warning p-4">You have not ordered for <?php echo e($resulttitle[$key]->title); ?> Meal yet</p>
                        
                        <a href="<?php echo e(route('student.order.createOrder',$resulttitle[$key]->id)); ?>" class="btn btn-danger btn-large btn-block"> ORDER From Food Menu  </a>
                        <?php else: ?>
                        <p class="text-white bg-danger p-4">Your <?php echo e($resulttitle[$key]->title); ?> Meal Order Time have been passed</p>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


   
    

</div>
<?php $__env->startSection('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
<link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

<!-- JavaScript code to calculate and display the remaining time -->
    <script>
        // The data/time we want to countdown to
        var countDownDate = new Date("<?php echo $remainingTime; ?>").getTime();
    
        // Run myfunc every second
        var myfunc = setInterval(function() {
    
        var now = new Date().getTime();
        var timeleft = countDownDate - now;
            
        // Calculating the days, hours, minutes and seconds left
        var hours = Math.floor((timeleft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        var minutes = Math.floor((timeleft % (1000 * 60 * 60)) / (1000 * 60));
        var seconds = Math.floor((timeleft % (1000 * 60)) / 1000);
            
        // Result is output to the specific element
        
        document.getElementById("hours").innerHTML = hours + " Hours " 
        document.getElementById("mins").innerHTML = minutes + " Minutes" 
        document.getElementById("secs").innerHTML = seconds + " Seconds " 
            
        // Display the message when countdown is over
        if (timeleft < 0) {
            clearInterval(myfunc);
            document.getElementById("hours").innerHTML = "" 
            document.getElementById("mins").innerHTML = ""
            document.getElementById("secs").innerHTML = ""
            document.getElementById("end").innerHTML = "TIME UP!!";
        }
        }, 1000);
        </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Larahall\resources\views/profile/dashboard.blade.php ENDPATH**/ ?>
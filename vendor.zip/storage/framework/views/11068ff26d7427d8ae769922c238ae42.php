
<?php $__env->startSection('title', 'Room Request Details'); ?>
<?php $__env->startSection('content'); ?>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Room Request Details 
                <a href="<?php echo e(route('admin.roomallocation.roomrequests')); ?>" class="float-right btn btn-success btn-sm" target="_self"> <i class="fa fa-arrow-left m-1 p-1"> </i>View All Room Requests</a> 
            </h6>
            
        </div>
        <div class="card-body">
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
            
            <div class="table-responsive">

                <table class="table table-bordered" width="100%">  
                    <tr>
                        <th style="width: 30%;">Status</th>
                        
                        <?php if($data->status=='1'): ?>
                        <td class="bg-success"> Accepted </td>
                        <?php elseif($data->status=='0'): ?>
                        <td class="bg-warning"> On Queue </td>
                        <?php elseif($data->status=='2'): ?>
                        <td class="bg-danger"> Rejected </td>
                        <?php else: ?>
                        <td> Requested </td>
                        <?php endif; ?>
                        
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo e($data2->name); ?></td>
                    </tr><tr>
                        <th>Roll</th>
                        <td><?php echo e($data2->rollno); ?> </td>
                    </tr><tr>
                        <th>Room no</th>
                        <td><?php echo e($data->rooms->title); ?> - <?php echo e($data->rooms->RoomType->title); ?> type </td>
                    </tr>
                    <tr>
                        <th>Application</th>
                        <td><?php echo e($data->message); ?></td>
                    </tr><tr>
                        <th>Application Date</th>
                        <td><?php echo e($data->created_at); ?></td>
                    </tr>
                    <tr>    
                        <?php if($data->status=='1'): ?>
                        <th class="bg-success"> Accepted Date </th>
                        <?php elseif($data->status=='0'): ?>
                        <th class="bg-warning"> Listed Date </th>
                        <?php elseif($data->status=='2'): ?>
                        <th class="bg-danger"> Rejected Date</th>
                        <?php else: ?>
                        <th> Last Checked Date </th>
                        <?php endif; ?>
                        <?php if($data->status=='1'): ?>
                        <td class="bg-success"> <?php echo e($data->updated_at); ?> </td>
                        <?php elseif($data->status=='0'): ?>
                        <td class="bg-warning"> <?php echo e($data->updated_at); ?> </td>
                        <?php elseif($data->status=='2'): ?>
                        <td class="bg-danger"> <?php echo e($data->updated_at); ?></td>
                        <?php else: ?>
                        <td> <?php echo e($data->updated_at); ?> </td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <th class="text-center">
                            <?php if($data->status!='1'): ?>
                            <a href="<?php echo e(url('admin/roomallocation/accept/'.$data->id)); ?>" class="btn btn-success btn-sm m-1"><i class="fa fa-check"> Accept </i></a>
                            <?php endif; ?>
                            <a onclick="return confirm('Are You Sure?')" href="<?php echo e(url('admin/roomallocation/list/'.$data->id)); ?>" class="btn btn-warning btn-sm m-1"><i class="fa fa-list" aria-hidden="true"> List </i></a>
                            <a onclick="return confirm('Are You Sure?')" href="<?php echo e(url('admin/roomallocation/ban/'.$data->id)); ?>" class="btn btn-danger btn-sm m-1"><i class="fa fa-ban" aria-hidden="true"> Reject </i></a>
                        </th>
                        <td>
                            <?php if($data->status!='1'): ?>
                            <a onclick="return confirm('Are You Sure?')" href="<?php echo e(url('admin/roomallocation/allocate/'.$data->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-check" aria-hidden="true"> Allocate Sit For <?php echo e($data2->rollno); ?> - Room No <?php echo e($data->rooms->title); ?> </i></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\0 New Project\Larahall Complete Meal Baki\Larahall2\resources\views/admin/roomallocation/roomrequestshow.blade.php ENDPATH**/ ?>
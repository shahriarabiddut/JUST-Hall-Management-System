
<?php $__env->startSection('title', 'Food Item'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h3 class="m-0 font-weight-bold text-primary">Food Item
            <a href="<?php echo e(route('staff.food.create')); ?>" class="float-right btn btn-success btn-sm" target="_blank">Add New</a> </h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Food Time</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Food Time</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($d->food_name); ?></td>
                            <td><?php echo e($d->foodtime->price); ?> /= Taka</td>
                            <?php switch($d->foodtime->title):
                            case ('Launch'): ?>
                                <td class="bg-warning text-white text-center"> <?php echo e($d->foodtime->title); ?> <i class="fas fa-sun"></i></td>
                                    <?php break; ?>
                            <?php case ('Dinner'): ?>
                            <td class="bg-info text-white text-center"> <?php echo e($d->foodtime->title); ?> <i class="fas fa-star"></i></td>
                                <?php break; ?>
                            <?php case ('Suhr'): ?>
                            <td class="bg-dark text-white text-center"> <?php echo e($d->foodtime->title); ?> <i class="fas fa-moon"></i></td>
                                <?php break; ?>
                            <?php endswitch; ?>
                                 
                            <?php switch($d->status):
                            case (0): ?>
                                <td class="bg-danger text-white text-center"> Disable</td>
                                    <?php break; ?>
                            <?php case (1): ?>
                            <td class="bg-success text-white text-center"> Active</td>
                                <?php break; ?>
                            <?php endswitch; ?>
                            
                            <td class="text-center">
                                <a href="<?php echo e(url('staff/food/'.$d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye">View </i></a>
                                <?php switch($d->status):
                                case (1): ?>
                                <a onclick="return confirm('Are You Sure?')" href="<?php echo e(url('staff/food/'.$d->id.'/disable')); ?>" class="btn btn-danger btn-sm"><i class="fa fa-ban">Disable</i></a>
                                        <?php break; ?>
                                <?php case (0): ?>
                                <a href="<?php echo e(url('staff/food/'.$d->id.'/active')); ?>" class="btn btn-success btn-sm"><i class="fa fa-check">Active</i></a>
                                    <?php break; ?>
                                <?php endswitch; ?>
                                
                                
                                
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\larahall\resources\views/staff/food/index.blade.php ENDPATH**/ ?>
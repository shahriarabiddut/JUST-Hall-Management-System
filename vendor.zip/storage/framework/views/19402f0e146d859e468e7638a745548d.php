<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-info sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('student.dashboard')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Student Panel</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('student.dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Hall Room Allocation
    </div>

    <!-- Nav Item Room - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/room*')): ?> collapsed <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fas fa-fw fa-hotel"></i>
            <span>Room</span>
        </a>
        <div id="collapseTwo" class="collapse <?php if(request()->is('student/room*')): ?> show <?php endif; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Room </h6>
            <?php if(isset($sorryRoomSidebar)): ?>
                <?php if($sorryRoomSidebar): ?>
                <a class="collapse-item" href="<?php echo e(route('student.myroom')); ?>">My Room Details</a> 
                <?php else: ?>
                <a class="collapse-item" href="<?php echo e(route('student.roomrequest')); ?>">New Room Request</a>
                <a class="collapse-item" href="<?php echo e(route('student.roomrequestshow')); ?>">My Room Requests</a>
                <?php endif; ?>
            <?php endif; ?> 
                
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Hall Meal System
    </div>

    <!-- Nav Item Meal - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/order*')): ?> collapsed <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseThree"
            aria-expanded="true" aria-controls="collapseThree">
            <i class="fas fa-fw fa-users"></i>
            <span>Meal</span>
        </a>
        <div id="collapseThree" class="collapse <?php if(request()->is('student/order*')): ?> show <?php endif; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Oeder Food</h6>
                <a class="collapse-item" href="<?php echo e(route('student.order.foodmenu')); ?>">View Food Menu</a>
                <a class="collapse-item" href="<?php echo e(route('student.order.index')); ?>">Order History</a>
                <a class="collapse-item" href="<?php echo e(route('student.mealtoken.index')); ?>">Meal Token History</a>
            </div>
        </div>
    </li>
     

    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Hall Balance System
    </div>
    <!-- Nav Item Balance - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/balance*')): ?>
            collapsed
        <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseSix"
            aria-expanded="true" aria-controls="collapseSix">
            <i class="fas fa-wallet"></i>
            <span>Balance</span>
        </a>
        <div id="collapseSix" class="collapse <?php if(request()->is('student/balance*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Balance Management</h6>
                <a class="collapse-item" href="<?php echo e(route('student.balance.index')); ?>">View Balance History</a>
            </div>
        </div>
    </li>
    <!-- Nav Item Payment - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/balance*')): ?>
            collapsed
        <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseEight"
            aria-expanded="true" aria-controls="collapseEight">
            <i class="fas fa-credit-card"></i>
            <span>Payment History</span>
        </a>
        <div id="collapseEight" class="collapse <?php if(request()->is('student/payments*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Payment Management</h6>
                <a class="collapse-item" href="<?php echo e(route('student.payments.index')); ?>">View Balance History</a>
                <a class="collapse-item" href="<?php echo e(route('student.payments.create')); ?>">Add new prepayment</a>
            </div>
        </div>
    </li>
    <!-- Nav Item Support - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/support*')): ?>
            collapsed
        <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseSeven"
            aria-expanded="true" aria-controls="collapseSeven">
            <i class="fas fa-ticket-alt"></i>
            <span>Support</span>
        </a>
        <div id="collapseSeven" class="collapse <?php if(request()->is('student/support*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Support Ticket Management</h6>
                <a class="collapse-item" href="<?php echo e(route('student.support.index')); ?>">View Support Tickets</a>
                <a class="collapse-item" href="<?php echo e(route('student.support.create')); ?>">Add New </a>
            </div>
        </div>
    </li>
   

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar - Logout - CopyRight) -->
    <?php echo $__env->make('../layouts/sidebar_toggle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Sidebar Toggler (Sidebar - Logout - CopyRight) -->

    

</ul>
<!-- End of Sidebar --><?php /**PATH H:\Larvel\2.7 Hall Manage - Meal token Generates with Order\resources\views////profile/sidebar_layout.blade.php ENDPATH**/ ?>
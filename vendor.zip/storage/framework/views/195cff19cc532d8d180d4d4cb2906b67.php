<ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/admin">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Staff Panel</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="/staff">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Hall Orders System
    </div>
    <!-- Nav Item Support - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/orders*')): ?>
            collapsed
        <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseEight"
            aria-expanded="true" aria-controls="collapseEight">
            <i class="fas fa-ticket-alt"></i>
            <span>Orders</span>
        </a>
        <div id="collapseEight" class="collapse <?php if(request()->is('student/orders*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Order Management</h6>
                <a class="collapse-item" href="<?php echo e(route('staff.orders.index')); ?>">Orders</a>
            </div>
        </div>
    </li>
     <!-- Divider -->
     <hr class="sidebar-divider">
     <!-- Heading -->
     <div class="sidebar-heading">
         Hall Food System
     </div>
     <!-- Nav FoodTime Services - Utilities Collapse Menu -->
     <li class="nav-item">
         <a class="nav-link <?php if(!request()->is('admin/foodtime*')): ?>
             collapsed
         <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseSix"
             aria-expanded="true" aria-controls="collapseSix">
             <i class="fas fa-table"></i>
             <span>FoodTime </span>
         </a>
         <div id="collapseSix" class="collapse <?php if(request()->is('admin/foodtime*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
             data-parent="#accordionSidebar">
             <div class="bg-white py-2 collapse-inner rounded">
                 <h6 class="collapse-header">FoodTime Management</h6>
                 <a class="collapse-item" href="<?php echo e(route('staff.foodtime.index')); ?>">View All</a>
                 <a class="collapse-item" href="<?php echo e(route('staff.foodtime.create')); ?>">Add new</a>
             </div>
         </div>
     </li>
     <!-- Nav FoodTime Services - Utilities Collapse Menu -->
     <li class="nav-item">
         <a class="nav-link <?php if(!request()->is('admin/food*')): ?>
             collapsed
         <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseSeven"
             aria-expanded="true" aria-controls="collapseSeven">
             <i class="fas fa-table"></i>
             <span>Food Items </span>
         </a>
         <div id="collapseSeven" class="collapse <?php if(request()->is('admin/foodtime*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
             data-parent="#accordionSidebar">
             <div class="bg-white py-2 collapse-inner rounded">
                 <h6 class="collapse-header">Food Item Management</h6>
                 <a class="collapse-item" href="<?php echo e(route('staff.food.index')); ?>">View All</a>
                 <a class="collapse-item" href="<?php echo e(route('staff.food.create')); ?>">Add new</a>
             </div>
         </div>
     </li>
   <!-- Divider -->
   <hr class="sidebar-divider">
   <!-- Heading -->
   <div class="sidebar-heading">
       Hall Balance System
   </div>

   <!-- Nav Item Balance - Pages Collapse Menu -->
   <li class="nav-item">
       <a class="nav-link <?php if(!request()->is('admin/balance*')): ?> collapsed <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseTwo"
           aria-expanded="true" aria-controls="collapseTwo">
           <i class="fas fa-wallet"></i>
           <span>Balance</span>
       </a>
       <div id="collapseTwo" class="collapse <?php if(request()->is('admin/balance*')): ?> show <?php endif; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
           <div class="bg-white py-2 collapse-inner rounded">
               <h6 class="collapse-header">Balance Management</h6>
               <a class="collapse-item" href="<?php echo e(route('staff.balance.index')); ?>">View All Customer</a>
               
           </div>
       </div>
   </li>
      <!-- Nav Item Payment - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('admin/payment*')): ?> collapsed <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseFour"
            aria-expanded="true" aria-controls="collapseFour">
            <i class="fas fa-credit-card"></i>
            <span>Payment</span>
        </a>
        <div id="collapseFour" class="collapse <?php if(request()->is('admin/payment*')): ?> show <?php endif; ?>" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Payment Management</h6>
                <a class="collapse-item" href="<?php echo e(route('staff.payment.index')); ?>">View All Payment</a>
                <a class="collapse-item" href="<?php echo e(route('staff.payment.create')); ?>">Add new Payment</a>
            </div>
        </div>
    </li>
    <!-- Divider -->
    <hr class="sidebar-divider">
    <!-- Heading -->
    <div class="sidebar-heading">
        Hall Email System
    </div>
    <!-- Nav Email Services - Utilities Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('staff/email*')): ?>
            collapsed
        <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseFive"
            aria-expanded="true" aria-controls="collapseFive">
            <i class="fas fa-table"></i>
            <span>Email Service</span>
        </a>
        <div id="collapseFive" class="collapse <?php if(request()->is('staff/email*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Email Management</h6>
                <a class="collapse-item" href="<?php echo e(route('staff.email.index')); ?>">View All</a>
                <a class="collapse-item" href="<?php echo e(route('staff.email.create')); ?>">Add new</a>
            </div>
        </div>
    </li>
     <!-- Nav Item Support - Utilities Collapse Menu -->
     <li class="nav-item">
        <a class="nav-link <?php if(!request()->is('student/support*')): ?>
            collapsed
        <?php endif; ?>" href="#" data-toggle="collapse" data-target="#collapseOne"
            aria-expanded="true" aria-controls="collapseOne">
            <i class="fas fa-ticket-alt"></i>
            <span>Support</span>
        </a>
        <div id="collapseOne" class="collapse <?php if(request()->is('student/support*')): ?> show <?php endif; ?>" aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Support Ticket Management</h6>
                <a class="collapse-item" href="<?php echo e(route('staff.support.index')); ?>">View Support Tickets</a>
            </div>
        </div>
    </li>
   

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
    <!--Logout - Dashboard -->
    <hr class="sidebar-divider d-none d-md-block">
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('staff.logout')); ?>">
            <i class="fas fa-fw fa-sign-out-alt"></i>
            <span>Logout</span></a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
    <!-- Sidebar Message -->
    <div class="sidebar-card d-none d-lg-flex">
        <img class="sidebar-card-illustration mb-2" src="<?php echo e(asset('img/justcse.png')); ?>" alt="...">
        <p class="text-center mb-2">JUST CSE</p>
        <a class="btn btn-success btn-sm" href="#">Shahriar Ahmed Biddut</a>
    </div>

    

</ul><?php /**PATH C:\xampp\htdocs\MultiAuth\resources\views////staff/sidebar_layout.blade.php ENDPATH**/ ?>
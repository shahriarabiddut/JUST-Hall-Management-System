
<?php $__env->startSection('title', 'Orders Search by date '); ?>

<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Orders Search by date</h1>
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
            <div class="card shadow mb-4 pl-4 py-2 bg-secondary text-white">
                <form method="POST" action="<?php echo e(route('staff.orders.searchByHistory')); ?>">
                    <?php echo csrf_field(); ?>
                    <label for="search-date">Search by Date with Details :</label>
                    <input type="date" id="search-date" name="date" value="<?php echo e($date); ?>">
                    <button type="submit">Search</button>
                  </form>
            </div>

            <!-- Content Row For Order Data of Selected Date -->
<div class="row">

    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="col-sm-6">
            <div class="card shadow mb-4">
                <div class="card-header py-3 
                <?php switch($resulttitle[$key]->title):
                    case ('Launch'): ?>
                        bg-warning
                        <?php break; ?>
                    <?php case ('Dinner'): ?>
                        bg-info
                        <?php break; ?>
                    <?php case ('Suhr'): ?>
                        bg-dark
                        <?php break; ?>
                    <?php case ('Special'): ?>
                        bg-danger
                        <?php break; ?>
                    <?php default: ?>
                        bg-secondary
                <?php endswitch; ?>
                ">
                    <h6 class="m-0 font-weight-bold text-white ">
                        <?php echo e($resulttitle[$key]->title); ?> Orders <i class="fas 
                        <?php switch($resulttitle[$key]->title):
                    case ('Launch'): ?>
                        fa-sun
                        <?php break; ?>
                    <?php case ('Dinner'): ?>
                        fa-star
                        <?php break; ?>
                    <?php case ('Suhr'): ?>
                        fa-moon
                        <?php break; ?>
                    <?php case ('Special'): ?>
                        fa-star
                        <?php break; ?>
                    <?php default: ?>
                        bg-secondary
                <?php endswitch; ?>
                        "></i>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php switch($key):
                                    case (1): ?>
                                        <table class="p-4 table-bordered float-left" width="50%">
                                            <tbody>
                                        <?php $__currentLoopData = $ld; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr><th class="p-4 text-center"><?php echo e($foods->food_name); ?> </th> </tr>
                                        
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                        <?php break; ?>
                                    <?php case (0): ?>
                                        <table class="table-bordered float-right" width="50%">
                                            <tbody>
                                            <?php $__currentLoopData = $ld; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $foodscount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr><th class="p-4 text-center"><?php echo e($foodscount); ?></th> </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <?php break; ?>
                                    <?php default: ?>
                                    <table class="table-bordered float-right" width="50%">
                                        <tbody>
                                        <tr><th class="p-4 text-center">No Data Available</th> </tr>
                                        </tbody>
                                    </table>
                                <?php endswitch; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                    </div>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('staff/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MultiAuth\resources\views/staff/orders/searchHistory.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Edit Settings'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Editing Settings</h1>
    <!-- Session Messages Starts -->
    <?php if(Session::has('success')): ?>
    <div class="p-3 mb-2 bg-success text-white">
        <p><?php echo e(session('success')); ?> </p>
    </div>
    <?php endif; ?>
    <?php if(Session::has('danger')): ?>
    <div class="p-3 mb-2 bg-danger text-white">
        <p><?php echo e(session('danger')); ?> </p>
    </div>
    <?php endif; ?>
    <!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="table-responsive">
                <form method="POST" action="<?php echo e(url('admin/settings/update/'.$data->id)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <tbody>
                        
                        <tr>
                            <th width="40%">
                                <?php switch($data->name):
                                    case ($data->name=='title'): ?>
                                        Website Title
                                        <?php break; ?>
                                    <?php case ($data->name=='fixed_cost_charge'): ?>
                                        Fixed Cost Charge
                                    <?php break; ?>
                                    <?php case ($data->name=='systemname'): ?>
                                        Dashboard Header Title
                                    <?php break; ?>
                                    <?php default: ?>
                                        <?php echo e($data->name); ?>

                                <?php endswitch; ?>
                                
                            </th>
                            <td width="40%"><input required name="value" type="text" class="form-control" value="<?php echo e($data->value); ?>"></td>
                            <td width="20%"><button type="submit" class="btn btn-primary">Update</button></td>
                        </tr>
                        </tbody>
                    </table>
                </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\2.7 Hall Manage - Meal token Generates with Order\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>
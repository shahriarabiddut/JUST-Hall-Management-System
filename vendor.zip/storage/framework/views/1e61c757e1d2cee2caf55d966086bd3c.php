
<?php $__env->startSection('title', 'Order '); ?>

<?php $__env->startSection('content'); ?>


    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Order Data</h1>
            <!-- Session Messages Starts -->
            <?php if(Session::has('success')): ?>
            <div class="p-3 mb-2 bg-success text-white">
                <p><?php echo e(session('success')); ?> </p>
            </div>
            <?php endif; ?>
            <?php if(Session::has('danger')): ?>
            <div class="p-3 mb-2 bg-danger text-white">
                <p><?php echo e(session('danger')); ?> </p>
            </div>
            <?php endif; ?>
            <!-- Session Messages Ends -->
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="row">
                <div class="col-sm">
                    <h6 class="m-0 font-weight-bold text-primary">Order History </h6>
                </div>
                <div class="col-sm float-left">
                    <select id="mySelect" class="m-1" class="float-left">
                        <option value="option"> Search By Date/ Month </option>
                        <option value="option2"> Search By Month </option>
                        <option value="option1"> Search By Date </option>
                      </select>
                </div>
                <div class="col-6 float-left">
                    <div id="myDiv" style="display: none;" >
                        <form method="POST" action="<?php echo e(route('student.order.searchByDate')); ?>">
                            <?php echo csrf_field(); ?>
                            <label for="search-date">Search by Date:</label>
                            <input type="date" id="search-date" name="date">
                            <button type="submit">Search</button>
                          </form>
                      </div>
                      <div id="myDiv2" style="display: none;">
                        <form method="POST" action="<?php echo e(route('student.order.searchByMonth')); ?>">
                            <?php echo csrf_field(); ?>
                            <label for="search-month">Search by Month:</label>
                            <input type="month" id="search-month" name="month">
                            <button type="submit">Search</button>
                        </form>
                      </div>
                </div>
              </div>
        </div>
        
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>FoodName</th>
                            <th>Food Time</th>
                            <th>Order Time</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>#</th>
                            <th>FoodName</th>
                            <th>Food Time</th>
                            <th>Order Time</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($d->food->food_name); ?></td>
                            <td><?php echo e($d->date); ?></td>
                            <td><?php echo e($d->order_type); ?></td>
                            <td><?php echo e($d->quantity); ?></td>
                            <td><?php echo e($d->price); ?></td>
                            
                            
                            <td class="text-center">
                                <a href="<?php echo e(url('student/order/'.$d->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye">View </i></a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startSection('scripts'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('js/demo/datatables-demo.js')); ?>"></script>
    <link href="<?php echo e(asset('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <script>
        const select = document.getElementById('mySelect');
        const div = document.getElementById('myDiv');
        const div2 = document.getElementById('myDiv2');

        select.addEventListener('change', (event) => {
        if (event.target.value === 'option1') {
            div.style.display = 'block';
            div2.style.display = 'none';
        }else if (event.target.value === 'option2') {
            div2.style.display = 'block';
            div.style.display = 'none';
        } else {
            div.style.display = 'none';
        }
        });

    </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Larvel\2.6 Hall Manage - Meal token & Maximum order\MultiAuth\resources\views/profile/order/index.blade.php ENDPATH**/ ?>